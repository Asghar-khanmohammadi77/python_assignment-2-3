import random
import math


while True:
    tas = math.ceil(random.random() * 6)
    if tas != 6:
        print("No. The number was: ",tas)
        break
    else:
        print('Yeah! 6 was the number.')
        question = input('Do you want to continue (y/n)? ')
        if question == 'y':
            continue
        elif question == 'n':
            break

