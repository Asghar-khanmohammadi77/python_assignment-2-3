arr = []
print("===============================")
while True:
    print('---------------------------')
    numinput = input("Enter a number: ")
    if numinput == 'exit':
        break
    arr.append(float(numinput))

sum = 0
for item in range(len(arr)):
    sum += arr[item]
print("===========")
print("Sum of above numbers: ",sum)
