import random
import math
arraylength = int(input("Enter the size of array (n): "))
arraymin = int(input("Enter min of numbers: "))
arraymax = int(input("Enter max of numbers: "))
arr = []
for item in range(arraylength):
    rand = math.floor(random.random() * arraymax) - math.floor(random.random() * arraymin)
    arr.append(rand)

print(arr)