import random
import math
guess = 1
answer = math.floor(random.random() * 100)

while True:
    print("----------------------------------")
    x = int(input("Please guess the number: "))
    
    if x > answer:
        print("Less")
        guess = guess + 1
    elif x < answer:
        print("More")
        guess = guess + 1
    else:
        print("Yes!!")
        print("Number of Guess: ",guess)
        break
