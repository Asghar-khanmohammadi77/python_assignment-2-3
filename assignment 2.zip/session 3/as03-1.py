arr1 = [1,2,4,3,3,5,5,6,6]
newarr = []
  
for no in range(len(arr1)):

    if arr1[no] == arr1[no - 1]:
        print('arr[',no,'] =',arr1[no],' <==> arr[',no-1,'] = ',arr1[no-1])
        
        continue
    else:
        newarr.append(arr1[no])

print(newarr)
        
    
