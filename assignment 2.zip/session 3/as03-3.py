import math
# Quadratic Equation
# y = ax2 + bx + c
print('The equation is: y=ax²+bx+c')

x1=0
x2=0
a = float(input("a= "))
b = float(input("b= "))
c = float(input("c= "))

delta = b**2 - 4*a*c

if delta > 0:
    print("We have 2 roots for this equation:")
    x1 = ((-b)+math.sqrt(delta))/2*a
    x2 = ((-b)-math.sqrt(delta))/2*a
    print(x1,x2)
elif delta == 0:
    print("We have 1 root for that:")
    x1 = (-b) / 2*a
    print(x1)
else:
    print("the equation has no answers.")