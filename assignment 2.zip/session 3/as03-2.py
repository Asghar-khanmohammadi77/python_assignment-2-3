row = int(input("enter the number of rows: "))
col = int(input("enter the number of columns: "))
strrow = ""
strtable = ""
isBlack = False
for c in range(col):

    for r in range(row):
        if isBlack:
            strrow +='#'
            isBlack = False
        else:
            strrow +='*'
            isBlack = True
    strtable += strrow + '\n'
    strrow = ""
    if isBlack:
        isBlack = False
    else:
        isBlack = True

print(strtable)